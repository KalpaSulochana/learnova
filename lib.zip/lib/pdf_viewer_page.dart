

import 'dart:typed_data';
import 'dart:ui' show FontFeature;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:learnova/colors.dart';
//import 'package:share_plus/share_plus.dart';
import 'package:syncfusion_flutter_pdfviewer/pdfviewer.dart';

/// A polished, Google Files-inspired PDF reader backed by Syncfusion's viewer.
///
/// Add these dependencies to pubspec.yaml:
///   syncfusion_flutter_pdfviewer: ^35.1.39
///   share_plus: ^13.3.1
///   http: any (let `flutter pub add http` select a compatible version)
///
/// The app using this page must also satisfy Syncfusion's licensing terms.
class PdfViewerPage extends StatefulWidget {
  final String pdfUrl;
  final String title;

  const PdfViewerPage({super.key, required this.pdfUrl, required this.title});

  @override
  State<PdfViewerPage> createState() => _PdfViewerPageState();
}

enum _ViewerMenuAction {
  jumpToPage,
  //copyLink,
  //shareLink,
  toggleScrollHead, //page counter side
  resetZoom,
  immersive, // full screen
}

class _PdfViewerPageState extends State<PdfViewerPage> {
  static const double _minZoom = 1.0;
  static const double _maxZoom = 4.0;
  final Color _lightCanvas = bgColor;

  final PdfViewerController _pdfViewerController = PdfViewerController();
  final TextEditingController _searchController = TextEditingController();
  final TextEditingController _pageInputController = TextEditingController();

  late PdfTextSearchResult _searchResult;

  bool _isLoading = true;
  bool _hasError = false;
  bool _showSearch = false;
  bool _isImmersive = false;
  bool _showScrollHead = false;
  bool _hasSubmittedSearch = false;
  String _errorMessage = '';
  Uint8List? _pdfBytes;
  int _currentPage = 1;
  int _pageCount = 0;
  int _loadAttempt = 0;
  double _zoomLevel = 1.0;

  @override
  void initState() {
    super.initState();
    _searchResult = PdfTextSearchResult();
    _searchResult.addListener(_handleSearchResultChanged);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) _loadPdfBytes();
    });
  }

  @override
  void didUpdateWidget(covariant PdfViewerPage oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.pdfUrl != widget.pdfUrl) {
      _searchResult.clear();
      _searchController.clear();
      _hasSubmittedSearch = false;
      _showSearch = false;
      _loadPdfBytes();
    }
  }

  @override
  void dispose() {
    _searchResult.removeListener(_handleSearchResultChanged);
    _searchResult.clear();
    _pdfViewerController.dispose();
    _searchController.dispose();
    _pageInputController.dispose();
    super.dispose();
  }

  void _handleSearchResultChanged() {
    if (mounted) setState(() {});
  }

  void _showMessage(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          content: Text(message),
          behavior: SnackBarBehavior.floating,
          duration: const Duration(seconds: 2),
        ),
      );
  }

  void _onDocumentLoaded(PdfDocumentLoadedDetails details) {
    if (!mounted) return;
    setState(() {
      _isLoading = false;
      _hasError = false;
      _errorMessage = '';
      _pageCount = _pdfViewerController.pageCount;
      _currentPage = _pdfViewerController.pageNumber
          .clamp(1, _pageCount)
          .toInt();
      _zoomLevel = _pdfViewerController.zoomLevel;
    });
  }

  void _onDocumentLoadFailed(PdfDocumentLoadFailedDetails details) {
    if (!mounted) return;
    setState(() {
      _isLoading = false;
      _hasError = true;
      _errorMessage = details.error;
    });
  }

  void _onPageChanged(PdfPageChangedDetails details) {
    if (!mounted) return;
    setState(() => _currentPage = details.newPageNumber);
  }

  void _onZoomChanged(PdfZoomDetails details) {
    if (!mounted) return;
    setState(() => _zoomLevel = details.newZoomLevel);
  }

  /// Downloads the complete PDF before handing bytes to Syncfusion.
  /// This avoids range-request quirks on some object-storage/CDN setups and
  /// detects Cloudflare HTML/error pages that may otherwise look like bad PDFs.
  Future<void> _loadPdfBytes() async {
    final int attempt = ++_loadAttempt;
    setState(() {
      _isLoading = true;
      _hasError = false;
      _errorMessage = '';
      _pdfBytes = null;
      _pageCount = 0;
      _currentPage = 1;
    });

    try {
      final Uri? uri = Uri.tryParse(widget.pdfUrl.trim());
      if (uri == null ||
          !uri.hasScheme ||
          (uri.scheme != 'https' && uri.scheme != 'http') ||
          uri.host.isEmpty) {
        throw const FormatException(
          'The PDF URL is invalid. Use a direct https:// or http:// object URL.',
        );
      }

      final http.Response response = await http
          .get(
            uri,
            headers: const <String, String>{
              'Accept':
                  'application/pdf,application/octet-stream;q=0.9,*/*;q=0.8',
            },
          )
          .timeout(const Duration(seconds: 60));

      if (!mounted || attempt != _loadAttempt) return;

      if (response.statusCode != 200) {
        final String explanation;
        if (response.statusCode == 401 || response.statusCode == 403) {
          explanation =
              'Storage denied access (HTTP ${response.statusCode}). ';
              //'Check that the object is public or use a valid, unexpired signed URL.'
              
        } else if (response.statusCode == 404) {
          explanation =
              'error 404  : file not found!';
        } else {
          explanation = 'The PDF server returned HTTP ${response.statusCode}.';
        }
        throw StateError(explanation);
      }

      final Uint8List bytes = response.bodyBytes;
      final bool startsWithPdfSignature =
          bytes.length >= 5 &&
          String.fromCharCodes(bytes.sublist(0, 5)) == '%PDF-';
      if (!startsWithPdfSignature) {
        final String contentType =
            response.headers['content-type'] ?? 'not provided';
        throw StateError(
          'The URL responded, but the response is not a PDF '
          '(Content-Type: $contentType). Cloudflare may be returning an HTML '
          'access-denied page, a login page, or a URL preview instead of the file. '
          'Use the direct object URL.',
        );
      }

      setState(() {
        _pdfBytes = bytes;
      });
    } catch (error) {
      if (!mounted || attempt != _loadAttempt) return;
      final String rawError = error.toString();
      final String normalizedError = rawError.replaceFirst(
        RegExp(r'^(Exception|StateError|FormatException|ClientException):\s*'),
        '',
      );
      final String lowerError = rawError.toLowerCase();
      final String visibleError;
      if (lowerError.contains('timeoutexception')) {
        visibleError =
            'The download timed out after 60 seconds.Check the connection.'/*' or PDF size.'*/;
      } else if (lowerError.contains('xmlhttprequest error') ||
          lowerError.contains('failed to fetch') ||
          lowerError.contains('clientexception')) {
        visibleError =
            '$normalizedError\n\nIf this is Flutter Web, check the Cloudflare R2 '
            'CORS policy for your app origin. If this is Android/iOS, check that '
            'the object URL is publicly accessible or is a valid presigned URL.';
      } else {
        visibleError = normalizedError;
      }
      setState(() {
        _isLoading = false;
        _hasError = true;
        _errorMessage = visibleError;
      });
    }
  }

  void _retryLoading() {
    _loadPdfBytes();
  }

  void _changeZoom(double delta) {
    if (_isLoading || _hasError) return;
    final double nextZoom = (_pdfViewerController.zoomLevel + delta)
        .clamp(_minZoom, _maxZoom)
        .toDouble();
    _pdfViewerController.zoomLevel = nextZoom;
    setState(() => _zoomLevel = nextZoom);
  }

  void _resetZoom() {
    if (_isLoading || _hasError) return;
    _pdfViewerController.zoomLevel = 1.0;
    setState(() => _zoomLevel = 1.0);
  }

  void _goToPage(int targetPage) {
    if (_pageCount <= 0) return;
    final int page = targetPage.clamp(1, _pageCount).toInt();
    _pdfViewerController.jumpToPage(page);
    FocusManager.instance.primaryFocus?.unfocus();
  }

  Future<void> _showPageJumpDialog() async {
    if (_pageCount <= 0) return;
    _pageInputController.text = '$_currentPage';

    final int? selectedPage = await showDialog<int>(
      context: context,
      builder: (BuildContext dialogContext) {
        //final ColorScheme colors = Theme.of(dialogContext).colorScheme;
        return AlertDialog(
          icon: Icon(Icons.find_in_page_rounded, color: primaryBlue),
          title: const Text('Go to page'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('This document has $_pageCount pages.'),
              const SizedBox(height: 16),
              TextField(
                controller: _pageInputController,
                autofocus: true,
                keyboardType: TextInputType.number,
                inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                textInputAction: TextInputAction.go,
                decoration: const InputDecoration(
                  labelText: 'Page number',
                  hintText: 'Enter a page number',
                  border: OutlineInputBorder(),
                ),
                onSubmitted: (_) => Navigator.of(
                  dialogContext,
                ).pop(int.tryParse(_pageInputController.text.trim())),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(),
              child: const Text('Cancel'),
            ),
            FilledButton(
              onPressed: () => Navigator.of(
                dialogContext,
              ).pop(int.tryParse(_pageInputController.text.trim())),
              child: const Text('Go'),
            ),
          ],
        );
      },
    );

    if (!mounted || selectedPage == null) return;
    if (selectedPage < 1 || selectedPage > _pageCount) {
      _showMessage('Enter a page number from 1 to $_pageCount.');
      return;
    }
    _goToPage(selectedPage);
  }

  void _openSearch() {
    setState(() {
      _showSearch = true;
      _isImmersive = false;
    });
  }

  void _runSearch() {
    final String query = _searchController.text.trim();
    if (query.isEmpty || _isLoading || _hasError) return;

    _searchResult.removeListener(_handleSearchResultChanged);
    _searchResult.clear();
    _searchResult = _pdfViewerController.searchText(query);
    _searchResult.addListener(_handleSearchResultChanged);
    setState(() => _hasSubmittedSearch = true);
  }

  void _clearSearch({bool closeToolbar = false}) {
    _searchResult.clear();
    _searchController.clear();
    setState(() {
      _hasSubmittedSearch = false;
      if (closeToolbar) _showSearch = false;
    });
  }

  void _closeSearch() {
    _clearSearch(closeToolbar: true);
    FocusManager.instance.primaryFocus?.unfocus();
  }







  /*
  Future<void> _copyDocumentLink() async {
    await Clipboard.setData(ClipboardData(text: widget.pdfUrl));
    if (mounted) _showMessage('PDF link copied');
  }
  */



  /*

  Future<void> _shareDocumentLink() async {
    try {
      await SharePlus.instance.share(
        ShareParams(
          title: widget.title,
          subject: widget.title,
          text: '${widget.title}\n${widget.pdfUrl}',
        ),
      );
    } catch (_) {
      if (mounted) _showMessage('Could not open the share menu.');
    }
  }

  */




  Future<void> _handleMenuAction(_ViewerMenuAction action) async {
    switch (action) {
      case _ViewerMenuAction.jumpToPage:
        await _showPageJumpDialog();
        break;

        /*
      case _ViewerMenuAction.copyLink:
        await _copyDocumentLink();
        break;
      case _ViewerMenuAction.shareLink:
        await _shareDocumentLink();
        break;
        */
      case _ViewerMenuAction.toggleScrollHead:
        setState(() => _showScrollHead = !_showScrollHead);
        break;
      case _ViewerMenuAction.resetZoom:
        _resetZoom();
        break;
      case _ViewerMenuAction.immersive:
        setState(() {
          _isImmersive = !_isImmersive;
          if (_isImmersive) _showSearch = false;
        });
        break;
    }
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      backgroundColor: bgColor,
      appBar: _isImmersive ? null : _buildAppBar(),
      body: SafeArea(
        top: _isImmersive,
        bottom: false,
        child: Stack(
          children: [
            Column(
              children: [
                if (_showSearch && !_isImmersive) _buildSearchBar(),
                Expanded(
                  child: Container(
                    color: _lightCanvas,
                    child: Stack(
                      children: [
                        if (_pdfBytes != null)
                          SfPdfViewer.memory(
                            _pdfBytes!,
                            key: ValueKey<int>(_loadAttempt),
                            controller: _pdfViewerController,
                            pageSpacing: 12,
                            maxZoomLevel: _maxZoom,
                            canShowScrollHead: _showScrollHead,
                            canShowScrollStatus: false,
                            canShowPaginationDialog: false,
                            currentSearchTextHighlightColor: const Color(
                              0xFFFFC857,
                            ),
                            otherSearchTextHighlightColor: const Color(
                              0xFFFFE9A8,
                            ),
                            onDocumentLoaded: _onDocumentLoaded,
                            onDocumentLoadFailed: _onDocumentLoadFailed,
                            onPageChanged: _onPageChanged,
                            onZoomLevelChanged: _onZoomChanged,
                          )
                        else
                          const SizedBox.expand(),
                        if (_isLoading && !_hasError)
                          _buildLoadingState(),
                        if (_hasError) _buildErrorState(),
                      ],
                    ),
                  ),
                ),
                if (!_isImmersive &&
                    !_isLoading &&
                    !_hasError &&
                    _pageCount > 0)
                  _buildBottomControls(),
              ],
            ),
            if (_isImmersive)
              Positioned(
                top: 12,
                right: 12,
                child: Material(
                  color: cardWhite,
                  elevation: 3,
                  shape: const StadiumBorder(),
                  child: IconButton(
                    tooltip: 'Show controls',
                    onPressed: () => setState(() => _isImmersive = false),
                    icon: const Icon(Icons.close_fullscreen_rounded),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      automaticallyImplyLeading: true,
      backgroundColor: primaryBlue,
      foregroundColor: Colors.white,
      surfaceTintColor: Colors.transparent,
      elevation: 0,
      scrolledUnderElevation: 0,
      titleSpacing: 0,
      title: Row(
        children: [
          Container(
            width: 38,
            height: 38,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(
              Icons.picture_as_pdf_rounded,
              color: primaryBlue,
              size: 22,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  widget.title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    letterSpacing: -0.2,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  _pageCount > 0 ? 'PDF · $_pageCount pages' : 'PDF document',
                  maxLines: 1,
                  style: TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w500,
                    color: Colors.white.withValues(alpha: 0.85),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
      actions: [
        IconButton(
          tooltip: 'Search in PDF',
          onPressed: _isLoading || _hasError ? null : _openSearch,
          icon:  Icon(Icons.search_rounded, color: cardWhite,),
        ),
        /*
        IconButton(
          tooltip: 'Share link',
          onPressed: _shareDocumentLink,
          icon: const Icon(Icons.ios_share_rounded),
        ),
        */
        PopupMenuButton<_ViewerMenuAction>(
          color: primaryBlue,
          tooltip: 'More options',
          onSelected: _handleMenuAction,
          itemBuilder: (BuildContext context) => [
            _menuItem(
              _ViewerMenuAction.jumpToPage,
              Icons.find_in_page_rounded,
              'Go to page',
              enabled: !_isLoading && !_hasError,
            ),
            /*
            _menuItem(
              _ViewerMenuAction.copyLink,
              Icons.link_rounded,
              'Copy PDF link',
            ),
            _menuItem(
              _ViewerMenuAction.shareLink,
              Icons.share_outlined,
              'Share PDF link',
            ),
            */
            _menuItem(
              _ViewerMenuAction.toggleScrollHead,
              Icons.tune_rounded,
              _showScrollHead ? 'Hide page scrubber' : 'Show page scrubber',
              enabled: !_isLoading && !_hasError,
            ),
            _menuItem(
              _ViewerMenuAction.resetZoom,
              Icons.fit_screen_rounded,
              'Reset zoom',
              enabled: !_isLoading && !_hasError,
            ),
            _menuItem(
              _ViewerMenuAction.immersive,
              Icons.fullscreen_rounded,
              'Immersive reading',
            ),
          ],
        ),
        const SizedBox(width: 4),
      ],
      bottom: PreferredSize(
        preferredSize: const Size.fromHeight(1),
        child: Divider(height: 1, thickness: 1, color: bgColor),
      ),
    );
  }

  PopupMenuItem<_ViewerMenuAction> _menuItem(
    _ViewerMenuAction value,
    IconData icon,
    String label, {
    bool enabled = true,
  }) {
    return PopupMenuItem<_ViewerMenuAction>(
      value: value,
      enabled: enabled,
      child: Row(
        children: [
          Icon(icon, size: 20, color: cardWhite,),
          const SizedBox(width: 12),
          Text(label, style: TextStyle(
            color: cardWhite
          ),),
        ],
      ),
    );
  }

  Widget _buildSearchBar() {
    final bool hasMatches = _hasSubmittedSearch && _searchResult.hasResult;
    final String resultLabel = hasMatches
        ? '${_searchResult.currentInstanceIndex} of ${_searchResult.totalInstanceCount}'
        : (_hasSubmittedSearch && _searchResult.isSearchCompleted
              ? 'No matches'
              : '');

    return Material(
      color: bgColor,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 10, 12, 12),
        child: Row(
          children: [
            Expanded(
              child: Container(
                decoration: BoxDecoration(
                  color: cardWhite,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: bgColor),
                ),
                child: TextField(
                  controller: _searchController,
                  autofocus: true,
                  textInputAction: TextInputAction.search,
                  onSubmitted: (_) => _runSearch(),
                  decoration: InputDecoration(
                    hintText: 'Find in document',
                    prefixIcon: const Icon(Icons.search_rounded, size: 21),
                    suffixIcon: _searchController.text.isEmpty
                        ? null
                        : IconButton(
                            tooltip: 'Clear search',
                            onPressed: () => _clearSearch(),
                            icon: const Icon(Icons.close_rounded, size: 19),
                          ),
                    border: InputBorder.none,
                    contentPadding: const EdgeInsets.symmetric(vertical: 13),
                  ),
                  onChanged: (_) => setState(() {}),
                ),
              ),
            ),
            const SizedBox(width: 4),
            if (resultLabel.isNotEmpty)
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 4),
                child: Text(
                  resultLabel,
                  style: TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w600,
                    color: hasMatches
                        ? primaryBlue
                        : textLight,
                  ),
                ),
              ),
            IconButton(
              tooltip: 'Previous match',
              onPressed: hasMatches ? _searchResult.previousInstance : null,
              icon: const Icon(Icons.keyboard_arrow_up_rounded),
            ),
            IconButton(
              tooltip: 'Next match',
              onPressed: hasMatches ? _searchResult.nextInstance : _runSearch,
              icon: const Icon(Icons.keyboard_arrow_down_rounded),
            ),
            IconButton(
              tooltip: 'Close search',
              onPressed: _closeSearch,
              icon: const Icon(Icons.close_rounded),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildBottomControls() {
    final bool canGoPrevious = _currentPage > 1;
    final bool canGoNext = _currentPage < _pageCount;
    final int zoomPercent = (_zoomLevel * 100).round();

    return Container(
      decoration: BoxDecoration(
        color: primaryBlue,
        border: Border(top: BorderSide(color: primaryBlue)),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
      child: SafeArea(
        top: false,
        child: Row(
          children: [
            IconButton(
              tooltip: 'Previous page',
              visualDensity: VisualDensity.compact,
              onPressed: canGoPrevious
                  ? () => _goToPage(_currentPage - 1)
                  : null,
              icon: const Icon(Icons.chevron_left_rounded, color: Colors.white),
            ),
            Material(
              color: cardWhite,
              borderRadius: BorderRadius.circular(12),
              child: InkWell(
                borderRadius: BorderRadius.circular(12),
                onTap: _showPageJumpDialog,
                child: Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 13,
                    vertical: 9,
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        '$_currentPage',
                        style: const TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 5),
                        child: Text(
                          '/',
                          style: TextStyle(color: textLight),
                        ),
                      ),
                      Text(
                        '$_pageCount',
                        style: TextStyle(
                          fontSize: 13,
                          color: textLight,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      const SizedBox(width: 5),
                      Icon(
                        Icons.unfold_more_rounded,
                        size: 16,
                        color: textLight,
                      ),
                    ],
                  ),
                ),
              ),
            ),
            IconButton(
              tooltip: 'Next page',
              visualDensity: VisualDensity.compact,
              onPressed: canGoNext ? () => _goToPage(_currentPage + 1) : null,
              icon: const Icon(Icons.chevron_right_rounded, color: Colors.white),
            ),
            const Spacer(),
            IconButton(
              tooltip: 'Zoom out',
              visualDensity: VisualDensity.compact,
              onPressed: _zoomLevel > _minZoom
                  ? () => _changeZoom(-0.25)
                  : null,
              icon: const Icon(Icons.remove_rounded, color: Colors.white),
            ),
            SizedBox(
              width: 47,
              child: Center(
                child: Text(
                  '$zoomPercent%',
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: Colors.white,
                    fontFeatures: const [FontFeature.tabularFigures()],
                  ),
                ),
              ),
            ),
            IconButton(
              tooltip: 'Zoom in',
              visualDensity: VisualDensity.compact,
              onPressed: _zoomLevel < _maxZoom ? () => _changeZoom(0.25) : null,
              icon: const Icon(Icons.add_rounded, color: Colors.white),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLoadingState() {
    return Positioned.fill(
      child: ColoredBox(
        color: bgColor.withValues(alpha: 0.96),
        child: Center(
          child: Container(
            constraints: const BoxConstraints(maxWidth: 250),
            margin: const EdgeInsets.all(24),
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: cardWhite,
              borderRadius: BorderRadius.circular(24),
              border: Border.all(color: bgColor),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.05),
                  blurRadius: 28,
                  offset: const Offset(0, 8),
                ),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                SizedBox(
                  width: 34,
                  height: 34,
                  child: CircularProgressIndicator(
                    strokeWidth: 3,
                    color: primaryBlue,
                  ),
                ),
                const SizedBox(height: 18),
                const Text(
                  'Opening PDF',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
                ),
                const SizedBox(height: 6),
                Text(
                  'Preparing your document…',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 12,
                    color: textLight,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildErrorState() {
    return Positioned.fill(
      child: ColoredBox(
        color: cardWhite,
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(28),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 360),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 76,
                    height: 76,
                    decoration: BoxDecoration(
                      color: bgColor,
                      borderRadius: BorderRadius.circular(24),
                    ),
                    child: Icon(
                      Icons.cloud_off_rounded,
                      size: 38,
                      color: primaryBlue,
                    ),
                  ),
                  const SizedBox(height: 22),
                  const Text(
                    'Couldn’t open this PDF',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Check your connection or make sure the document link is still available, then try again.',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      height: 1.5,
                      fontSize: 14,
                      color: textLight,
                    ),
                  ),
                  if (_errorMessage.trim().isNotEmpty) ...[
                    const SizedBox(height: 12),
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: bgColor.withValues(
                          alpha: 0.6,
                        ),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Text(
                        _errorMessage,
                        maxLines: 4,
                        overflow: TextOverflow.ellipsis,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 11,
                          color: textLight,
                        ),
                      ),
                    ),
                  ],
                  const SizedBox(height: 22),
                  FilledButton.icon(
                    onPressed: _retryLoading,
                    icon: const Icon(Icons.refresh_rounded),
                    label: const Text('Try again'),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
